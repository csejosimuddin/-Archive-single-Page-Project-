<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\categories;
use Carbon\Carbon;

class CategoriesController extends Controller
{
  function index(){
      $categories = categories::all();
      return view('category.view',compact('categories'));
  }


  function addcategoryinsert(Request $request){
    // Form-Validation
    $request->validate([
        'category_name' => 'required|unique:categories,category_id'
    
    ]);

    if(isset($request->menu_status)){
        // categories যোগ করার জনে	
    
  categories::insert([
        'category_id' => $request->category_name,
        'menu_status' =>true,
        'created_at' => Carbon::now()
    ]);


    }

    else{
      categories::insert([
        'category_id' => $request->category_name,
        'menu_status' =>false,
        'created_at' => Carbon::now()
    ]);
    }

    // categories যোগ করার জনে	
    
  // categories::insert([
  //       'category_id' => $request->category_name,
  //       'created_at' => Carbon::now()
  //   ]);


    return back()->with('status', 'Product Insert SuccessFully!');
}


}
