<?php $__env->startSection('content'); ?>


<div class="page-info-section page-info">
<div class="container">
<div class="site-breadcrumb">
<a href="#">Home</a> /
<a href="#">Product</a> 
</div>
<img src="img/page-info-art.png" alt="" class="page-info-art">
</div>
</div>



<div class="container">
	<div class="row">
<div class="col-lg-12">
<h2 class="text-center mb-5 mt-5">Category or Archive Product Page</h2>
	
</div>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-3">

		<div class="card mb-5">
		 <a href="<?php echo e(category/wise/product); ?>/<?php echo e($category->id); ?>"> 
			<img src="img/intro/5.jpg">
			 </a> 
			<div class="card-body">
				<h5 class="card-title">Product Title</h5>
					<span>$1250</span>
				<button type="button" class="btn btn-outline-primary">Add To Cart</button>

  			</div>

		</div>
		
	</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</div>
	
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CIT\josim\resources\views/frontend/Category_product.blade.php ENDPATH**/ ?>